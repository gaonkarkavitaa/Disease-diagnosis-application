package com.pavan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMlIntegrationApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootMlIntegrationApplication.class, args);
    }
}
